#include "chara.h"

Chara::Chara():numberChara(0){}

Chara::Chara(int nbChara):numberChara(nbChara){}

Chara::Chara(int nbChara, int slChara):numberChara(nbChara), selectedChara(slChara){}