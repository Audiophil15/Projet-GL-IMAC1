#ifndef BLOCK_H
#define BLOCK_H

#include "rectangle.h"

class Block : public Rectangle {
	using Rectangle::Rectangle;

	public:
		glm::vec2 speed;
		glm::vec2 acc;
		glm::vec2 adherence;

	public:

		Block(int adh); 
		Block(int pos, int size, int adh);
		Block(int x, int y, int w, int h, int adhX, int adhY);
		Block(int x, int y, int w, int h, int adhX, int adhY, double r, double g, double b);
		Block(int x, int y, int w, int h, int adhX, int adhY, int accX, int accY);
		Block(int x, int y, int w, int h, int adhX, int adhY, int accX, int accY, double r, double g, double b);

		void moveto(int x, int y);
		void moverel(int x, int y);
		int getPosX();
		int getPosY();
		int getwidth();
		int getheight();
};

#endif