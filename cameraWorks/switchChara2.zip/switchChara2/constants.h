static int SCR_W = 800;
static int SCR_H = 400;
static int INIT_W = 800;
static int INIT_H = 400;
static float SCR_RATIO = 2.0; // W/H
static int cameraX = 0;
static int cameraY = 0;
static int selectedChara=0;