#include <SDL2/SDL.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <unistd.h>
#include <stdio.h>

#include "color.h"
#include "block.h"
#include "rectangle.h"
#include "window.h"
#include "graphics.h"
#include "chara.h"

void axis(int baseW, int baseH);

int main(){

	Window win;
	Chara chara(3);

	initSDL();
	win.SDLWindow = initWindow(win.scrW, win.scrH);
	win.GLContext = contextInit(win.SDLWindow);
	windowResize(win.scrW, win.scrH, win);

	const Uint8* keystate = SDL_GetKeyboardState(NULL);

	int quit = 0;
	SDL_Event e;

	int numberChara = 3;

	Block* charaTab = (Block*)malloc(sizeof(Block)*chara.numberChara);

	Block perso1(win.scrW/2, win.scrH/2, 15, 30, 4, 220, 0, -9.8, 0.921, 0.376, 0.376);
	Block perso2(win.scrW/2 - 100, win.scrH/5, 15, 15, 5, 250, 0, -9.8, 0.937, 0.933, 0.560);
	Block perso3(win.scrW/2 + 100, win.scrH/5, 30, 30, 3, 280, 0, -9.8, 0.937, 0.560, 0.870);

	Rectangle plateforme(0, win.scrH/5, win.scrW, -win.scrH/5);

	charaTab[0] = perso1;
	charaTab[1] = perso2;
	charaTab[2] = perso3;
	
	int camx =0;
	int camy=0;

	double dt = 1.0/60;
	int accelFactor = 50; 
	int injump = 0;

	while(!quit){

		while(SDL_PollEvent(&e)){
			switch (e.type){
			case SDL_QUIT:
				quit = 1;
			break;

			case SDL_WINDOWEVENT:
				if (e.window.event == SDL_WINDOWEVENT_RESIZED){
					windowResize(e.window.data1, e.window.data2, win);
				}
			case SDL_KEYDOWN : 
				switch(e.key.keysym.sym){
					case SDLK_q:
					case SDLK_ESCAPE:
						quit = 1;
					break;

					case SDLK_TAB : 
						
						if(chara.selectedChara <2){
							chara.selectedChara+=1;
						}else {
							chara.selectedChara=0;
						} 

						if(chara.selectedChara> 0){
							chara.previousChara= chara.selectedChara - 1;
						}else{
							chara.previousChara =2;
						}

					break;
			
					
					case SDLK_UP:
						if(!injump){
							charaTab[chara.selectedChara].speed.y = charaTab[chara.selectedChara].adherence.y;
							injump = 1;
						}
					break;

				}


			default:
			break;
			}
		}

	if (keystate[SDL_SCANCODE_LEFT] || keystate[SDL_SCANCODE_RIGHT]){
			if (keystate[SDL_SCANCODE_LEFT]){

				//charaTab[selectedChara].moveto(charaTab[selectedChara].position.x - charaTab[selectedChara].adherence.x, charaTab[selectedChara].position.y);
				charaTab[chara.selectedChara].position.x -= charaTab[chara.selectedChara].adherence.x;
			}
			if (keystate[SDL_SCANCODE_RIGHT]){

				//charaTab[selectedChara].moveto(charaTab[selectedChara].position.x + charaTab[selectedChara].adherence.x, charaTab[selectedChara].position.y);
				charaTab[chara.selectedChara].position.x += charaTab[chara.selectedChara].adherence.x;
			}
		}

		// Updates physics variables

		charaTab[chara.selectedChara].speed.x += dt* charaTab[chara.selectedChara].acc.x;
		charaTab[chara.selectedChara].speed.y += dt*charaTab[chara.selectedChara].acc.y * accelFactor;		
		charaTab[chara.selectedChara].position.x += dt*charaTab[chara.selectedChara].speed.x;
		charaTab[chara.selectedChara].position.y += dt*charaTab[chara.selectedChara].speed.y;

		charaTab[chara.previousChara].speed.y += dt*charaTab[chara.previousChara].acc.y * accelFactor;	
		charaTab[chara.previousChara].position.y += dt*charaTab[chara.previousChara].speed.y;
		

		// Detects collision
		if (charaTab[chara.selectedChara].position.y<plateforme.position.y){
			charaTab[chara.selectedChara].position.y -= dt*charaTab[chara.selectedChara].speed.y;
			charaTab[chara.selectedChara].speed.y = 0;
			injump = 0;
		}

		if (charaTab[chara.previousChara].position.y<plateforme.position.y){
			charaTab[chara.previousChara].position.y -= dt*charaTab[chara.previousChara].speed.y;
			charaTab[chara.previousChara].speed.y = 0;
		}

		camx = charaTab[chara.selectedChara].position.x;
		camy = charaTab[chara.selectedChara].position.y;

		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		// camera
			
		glColor3f(1,0,0);
		axis(win.baseW, win.baseH);
		

		glPushMatrix();

			glTranslatef(-camx + win.baseW/2, -camy + win.baseH/5, 0);			
			glColor3f(0,1,0);
			axis(win.baseW, win.baseH);

			plateforme.draw();
			for(int i=0; i< numberChara; i++){
			charaTab[i].draw();
			}

		glPopMatrix();
		SDL_GL_SwapWindow(win.SDLWindow);
	}

	SDL_GL_DeleteContext(win.GLContext);
	SDL_DestroyWindow(win.SDLWindow);
	SDL_Quit();

}


void axis(int baseW, int baseH){
	glPushMatrix();
	glBegin(GL_LINES);
		glVertex2f(baseW/2 - 30, baseH/2);
		glVertex2f(baseW/2 + 30, baseH/2);
	glEnd();

	glBegin(GL_LINES);
		glVertex2f(baseW/2, baseH/2 - 30);
		glVertex2f(baseW/2, baseH/2 + 30);

	glEnd();
	glPopMatrix();
}






