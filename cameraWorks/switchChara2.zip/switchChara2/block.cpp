#include "block.h"

Block::Block(int adh):Rectangle{0,0,25,25,1,1,1}, speed({0,0}), acc({0,0}), adherence({adh,adh}){}

Block::Block(int pos, int size, int adh):Rectangle{pos,pos,size,size,1,1,1}, speed({0,0}), acc({0,0}), adherence({adh,adh}){}

Block::Block(int x, int y, int w, int h, int adhX, int adhY):Rectangle{x,y,w,h,1,1,1}, speed({0,0}), acc({0,0}), adherence({adhX,adhY}){}

Block::Block(int x, int y, int w, int h, int adhX, int adhY, double r, double g, double b):Rectangle{x,y,w,h,r,g,b}, speed({0,0}), acc({0, 0}), adherence({adhX,adhY}){}

Block::Block(int x, int y, int w, int h, int adhX, int adhY, int accX, int accY):Rectangle{x,y,w,h,1,1,1}, speed({0,0}), acc({accX,accY}), adherence({adhX,adhY}){}

Block::Block(int x, int y, int w, int h, int adhX, int adhY, int accX, int accY, double r, double g, double b):Rectangle{x,y,w,h,r,g,b}, speed({0,0}), acc({accX, accY}), adherence({adhX,adhY}){}


void Block::moveto(int x, int y){
	this->position.x = x;
	this->position.y = y;
}

void Block::moverel(int dx, int dy){
	this->position.x += dx;
	this->position.y += dy;
}

int Block::getPosX(){
	return this->position.x;
}

int Block::getPosY(){
	return this->position.y;
}

int Block::getwidth(){
	return this->size.x;
}

int Block::getheight(){
	return this->size.y;
}
