#include "color.h"

void ColorRGB::set(double r, double g, double b){
	this->r = r;
	this->g = g;
	this->b = b;
}