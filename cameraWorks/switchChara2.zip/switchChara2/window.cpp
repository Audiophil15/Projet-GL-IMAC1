#include "window.h"

Window::Window():scrW(800), scrH(400){};

